<?php
namespace Grav\Plugin;

use Composer\Autoload\ClassLoader;
use Grav\Common\Plugin;
use Grav\Common\Debugger;
use Grav\Common\Grav;
use Grav\Plugin\Pagetransfer\Classes\TransferLogic;

/**
 * Class PagetransferPlugin
 * @package Grav\Plugin
 */

class PagetransferPlugin extends Plugin
{
    protected $debugon;

    public static function getSubscribedEvents(): array
    {
        return [
            	'onPluginsInitialized' => ['onPluginsInitialized', 0]
        ];
    }

    public function autoload(): ClassLoader
    {
        return require __DIR__ . '/vendor/autoload.php';
    }


    public function onPluginsInitialized(): void
    {
        if ($this->grav['user']->authenticated && $this->isAdmin()) {
		$this->enable([
                'onAdminMenu' => ['onAdminMenu', 0],
		'onTwigTemplatePaths' => ['onTwigTemplatePaths', 0],
		'onPagesInitialized' => ['onPagesInitialized', 0],
		'onAdminTaskExecute' => ['onAdminTaskExecute', 0],
             	]);
        }
    }

	public function addDebugInfo($title,$obj)	
	{
		if ($this->debugon){
		  $grav = Grav::instance();
		  $debugger = $grav['debugger'];
		  $info_formatted = var_export($obj, true);
		 $debugger->addMessage($title . ' : ' . $info_formatted, 'info');
		}
		return true;
	}

	public function onAdminMenu()
	{
	// Add button to admin menu
    	$this->grav['twig']->plugins_hooked_nav['Pages transfer'] = ['route' => 'pagetransfer', 'icon' => 'fa-exchange'];
        $this->debugon = $this->config->get('plugins.pagetransfer.debugon');
    	$protected_paths = $this->grav['uri']->paths();

    	// Should we proceed for transfer
    	if ($this->grav['uri']->path() === '/admin/task/transferPages') {
		$this->addDebugInfo('Request : ', $this->grav['request']);
        	// Get pages to be transfered in datas from POST
        	$postData = $this->grav['request']->getParsedBody();
        	$pages = isset($postData['pages']) ? $postData['pages'] : [];
        	$this->addDebugInfo('Pages to transfer:  ', $pages);

	        // Get plugin config
        	$pluginConfig = $this->config;

	        // Get new instance of transfer logic and execute
        	$transferLogic = new TransferLogic($pluginConfig);
        	$result = $transferLogic->transferPages($pages);

        	// Store results in session
        	$this->grav['session']->setFlashObject('transfer_result', $result);
        	// Redirect to page itself to show results
		if (!$this->debugon)
        		$this->grav->redirect($this->grav['uri']->path() . '/results');
	    }

    		// Show results or not ?
    		if ($this->grav['uri']->path() === '/admin/task/transferPages/results') {
        		// Get back result stored in session
        		$result = $this->grav['session']->getFlashObject('transfer_result');
			$this->addDebugInfo('Result:  ', $result);
        		// Push results to Twig vars
        		$this->grav['twig']->twig_vars['transfer_result'] = $result;
        		// Define template to show results
        		$page = new \Grav\Common\Page\Page();
        		$page->init(new \SplFileInfo(__DIR__ . '/pages/admin/transfer_results.md'));
        		$page->template('transfer_results');
        		$this->grav['page'] = $page;
    		}
	}

    public function onTwigTemplatePaths()
    {
        // Add path template to general Twig mecanism
        $this->grav['twig']->twig_paths[] = __DIR__ . '/templates';
    }

	public function onPagesInitialized()
	{
    		$uri = $this->grav['uri'];
		$this->addDebugInfo('URI informations: ', $this->grav['uri']);
    		if ($uri->path() === '/admin/pagetransfer') {
        		$page = new \Grav\Common\Page\Page();
        		$page->init(new \SplFileInfo(__DIR__ . '/pages/admin/pagetransfer.md'));
        		$page->template('pagetransfer');  // Use template Twig `pageTransfer.html.twig`
        		$this->grav['page'] = $page;
    		}
	}

}
