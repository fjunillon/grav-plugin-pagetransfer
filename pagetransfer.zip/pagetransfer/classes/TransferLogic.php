<?php
namespace Grav\Plugin\Pagetransfer\Classes;
use Grav\Common\Grav;
use Grav\Common\Debugger;
use Grav\Common\Plugin;
use phpseclib3\Net\SFTP;
use phpseclib3\Crypt\RSA;
use phpseclib3\Crypt\PublicKeyLoader;

class TransferLogic
{
    protected $remoteHost;
    protected $sshKeyPath;
    protected $remote_user;
    protected $remote_path;
    protected $pluginConfig;
    protected $debugon;

    public function __construct($plugConfig)
    {
	$this->pluginConfig = $plugConfig;
        $this->remoteHost = $this->pluginConfig->get('plugins.pagetransfer.remote_host');
        $this->sshKeyPath = $this->pluginConfig->get('plugins.pagetransfer.ssh_key_path');
        $this->remoteUser = $this->pluginConfig->get('plugins.pagetransfer.remote_user');
        $this->remotePath = $this->pluginConfig->get('plugins.pagetransfer.remote_path');
        $this->transfersubdir = $this->pluginConfig->get('plugins.pagetransfer.transfersubdir');
        $this->usebeforeafter = $this->pluginConfig->get('plugins.pagetransfer.usebeforeafter');
        $this->debugon = $this->pluginConfig->get('plugins.pagetransfer.debugon');
    }

	public function addDebugInfo($title,$obj)
	{
	  if ($this->debugon){
            $grav = Grav::instance();
            $debugger = $grav['debugger'];
            $info_formatted = print_r($obj, true);
            $debugger->addMessage($title . ' : ' . $info_formatted, 'info');
    	  }
	  return true;
	}

    public function beforeAfter($filename)
    {
	$this->addDebugInfo("Distant filename: ",$filename);
        $keywords= $this->pluginConfig->get('plugins.pagetransfer.beforeafter') ?? [];
	if (empty($keywords)){
		$result[] = [
			'command'=> 'null',
                	'page' => $filename,
                        'output' => 'Before/after nothing to show',
                        'success' => 'true'
                        ];
		return $result;
	}
        foreach ($keywords as $pair) {
		$escapedKey=str_replace('/', '\\/', $pair['key']);
		$escapedValue=str_replace('/', '\\/', $pair['value']);
		$this->addDebugInfo("KeyWord: ",'Key: ' . $escapedKey . ', Word: ' . $escapedValue);
		//use sed tp change
		if ($this->sshKeyPath==''){
			$command = sprintf(
                        'ssh  %s@%s "sudo -u www-data find %s -type f -exec sed -i \'s|%s|%s|g\' {} +"',
                        $this->remoteUser,
                        $this->remoteHost,
                        $filename,
                        $escapedKey,
                        $escapedValue );
                        $this->addDebugInfo("command : ",$command);
		}
		else 
		{
			$command = sprintf(
			'ssh -i %s  %s@%s "sudo -u www-data find %s -type f -exec sed -i \'s|%s|%s|g\' {} +"',
			$this->sshKeyPath,
			$this->remoteUser,
			$this->remoteHost,
			$filename,
			$escapedKey,
			$escapedValue );
                	$this->addDebugInfo("command : ",$command);
		}
		//command execute
                exec($command . ' 2>&1', $output, $returnVar);
                $result[] = [
			'command' => $command,
                        'page' => $filename,
                        'output' => $output,
                        'success' => $returnVar === 0
                        ];
                $this->addDebugInfo("result beforeafter: ",$result);
	}
	return $result;
    }

    private function beforeAfterStream($filename, $outputStream, $keywords)
    {
        $this->addDebugInfo("Local filename: ",$filename);
	$inputStream = fopen($filename, 'r');
	if (!$inputStream) {
                $result[] = [
                        'command'=> 'beforeAfter fopen',
                        'page' => $filename,
                        'output' => 'Impossible to read',
                        'success' => 'false'
                        ];
                return $result;
	}
	$tempStream = fopen('php://temp', 'c+');
	while (($line = fgets($inputStream)) !== false) {
		fwrite($tempStream, $line);
	}
	fclose($inputStream);

	foreach ($keywords as $pair) {
		$this->addDebugInfo("KeyWord: ", 'Key: ' . $pair['key'] . ', Word: ' . $pair['value']);
		// Reinit position of read for each new key
		rewind($outputStream); 
		rewind($tempStream); 

		while (($line = fgets($tempStream)) !== false) {
        		// Replace key by word in the line
        		$modifiedLine = str_replace($pair['key'], $pair['value'], $line);
        		$this->addDebugInfo("beforeAfter modify: ", $line . ' -> ' . $modifiedLine);
		        // Écrit la ligne modifiée dans le flux de sortie
        		fwrite($outputStream, $modifiedLine);
    		}
		rewind($outputStream); 
                rewind($tempStream);
              	while (($line = fgets($outputStream)) !== false) {
                        fwrite($tempStream, $line);
                } 
	}

	fclose($tempStream);
	rewind($outputStream);
	$result[] = [
        	'command' => 'beforeAfter stream modify',
                'page' => $filename,
                'output' => '',
                'success' => true
                ];
        $this->addDebugInfo("result stream beforeafter: ",$result);
        return $result;
    }

    public function transferPages($pages)
    {
	$this->addDebugInfo("transferPages: ",$pages);
        $selectedOption = $this->pluginConfig->get('plugins.pagetransfer.tool.select_option');
	switch($selectedOption)
	{
    	  case 'option1';
		$result=$this->rsyncPages($pages);
		break;
    	  case 'option2';
		$result=$this->sftpPages($pages);
		break;
    	  default;
		$result=$this->rsyncPages($pages);
        	break;
	}
	return $result;
     }

     private function sftpPages($pages){
        $result = [];
	$resultFtp = [];
        $localPath = GRAV_ROOT . '/user/pages/';
	try {
		$sftp = new SFTP($this->remoteHost, '22');
		$this->sshKeyPath= '/var/www/.ssh/id_rsa';
		$this->remoteUser='www-data';
                $key = PublicKeyLoader::load(file_get_contents($this->sshKeyPath));
                if (!$sftp->login($this->remoteUser, $key)) {
	    		$errorMessage = $sftp->getLastSFTPError();
			$this->addDebugInfo("ErrorFTP: ","->".$errorMessage);
                	$result[] = [
                        	'command' => "sftp no login",
                        	'page' => "",
                        	'output' => $errorMessage,
                        	'success' => false
                        	];
        	} else{
		foreach ($pages as $page){ 
            			$this->addDebugInfo("calling recursiveTransfer with: ",$page.' -> '.$this->remotePath );
				$resultFtp=$this->recursiveTransfer($sftp, $page, $this->remotePath);
				$result=array_merge( $result,$resultFtp);
        		}
			$sftp->disconnect();
		}
	} catch (Exception $e) {
                $result[] = [
                        'command' => "sftp",
                        'page' => "",
                        'output' => $e->getMessage(),
                        'success' => false
                        ];
	}
	return $result;
     }

    private function recursiveTransfer($sftp, $src, $destination)
    {
	$result = [];
	$localPath = GRAV_ROOT . '/user/pages/';
	$this->addDebugInfo("page requested: ",$src);
        $source = str_replace($localPath, "",  $src);
	$this->addDebugInfo("try create dest path: ",$source);
	$file = $this->sftp_mkdir_recursive($sftp,$source);
	if ($file!= false) {
		$this->addDebugInfo("transfer put file: ",$src . ' -> ' .  $destination.'/'.$source);
		if ($sftp->chdir($destination).'/'.$source) {
			$this->addDebugInfo("chg to dir destination: ",' OK exist '.$destination.'/'.$source);
			$files = scandir($src);
                	foreach ($files as $file) {
				if ($file != '.' && $file != '..'){
                			try {
						if (is_dir($src.'/'.$file)){
							if ($this->transfersubdir==true){
								$this->addDebugInfo("found subdir, try create dest path: ",$source.'/'.$file.'->'.$destination);
								$this->recursiveTransfer($sftp, $src.'/'.$file, $destination);
							}
						} else
						{
							$this->addDebugInfo("try put file: ",$src.'/'.$file.' -> '.$destination.'/'.$source.'/'.$file);
							$filePerms = fileperms($src.'/'.$file);
							$mimeType = mime_content_type($src.'/'.$file);
							$keywords= $this->pluginConfig->get('plugins.pagetransfer.beforeafter') ?? [];
        						if (!str_contains($mimeType,'text') || empty($keywords) || !$this->usebeforeafter) {
								$putResult=$sftp->put($destination.'/'.$source.'/'.$file, $src.'/'.$file, SFTP::SOURCE_LOCAL_FILE);
        						}else{
								$outputStream = fopen('php://temp', 'w+');
								$resultStream=$this->beforeAfterStream($src.'/'.$file, $outputStream, $keywords);
								$result=array_merge( $result,$resultStream);
								if ($resultStream[0]['success']==true)
									$putResult = $sftp->put($destination.'/'.$source.'/'.$file, $outputStream, SFTP::SOURCE_LOCAL_FILE);
								fclose($outputStream);
							}
							if ($putResult) {
								$this->addDebugInfo("put result: ",'OK');
								$this->addDebugInfo("changing file perms on destination: ",$destination.'/'.$source.'/'.$file); 
								$sftp->chmod($filePerms, $destination.'/'.$source.'/'.$file);
							}
        						$resultFtp[] = [
                        					'command' => "sftp put",
                        					'page' => $source.' -> '.$destination,
                      						'output' =>  "",
                        					'success' => 1
                        				];
        						$result=array_merge( $result,$resultFtp);
						}
					} catch (Exception $e) {
						$this->addDebugInfo("put exception: ",$e->getMessage());
					}
				}
			} 
		} else {
			$this->addDebugInfo("chg to dir destination: ",' KO not exist '.$destination);
			$result[] = [
				'command' => "sftp chdir",
                                'page' => $destination,
                                'output' =>  "",
                                'success' => 0
                        ];
		}
	}
	return $result;
    }
	function sftp_mkdir_recursive($sftp,$path, $mode = 0755) {
		//Split directory and file name
    		$fileName = '';
		$remoteBaseDir=$this->remotePath;
		$this->addDebugInfo("creating dest path: ",$path);
    		if (is_file($path)) {
        		$fileName = basename($path);
        		$path = dirname($path);
    			$this->addDebugInfo("getting path and file: ",$path.'->'.$fileName);
		}
    		//split directories
    		$dirs = explode('/', $path);
    		$currentDir = '';
    		foreach ($dirs as $dir) {
        		if (empty($dir)) {
				continue;
        		}
			$currentDir .= '/' . $dir;
			$this->addDebugInfo("testing current dir: ",$currentDir);
        		if (!$sftp->is_dir($currentDir)) {
        			if (!$sftp->mkdir($remoteBaseDir.$currentDir, $mode)) {
					$this->addDebugInfo("create path NOK (already exist or no rights to create): ",$remoteBaseDir.$currentDir);
            			}
        		}
    		}
		return $fileName ? $fileName : true;
	}

    private function rsyncPages($pages){
        $result = [];
        $localPath = GRAV_ROOT . '/user/pages/';
        $this->addDebugInfo("localPath: ",$localPath);
	foreach ($pages as $page) {
		$this->addDebugInfo("page avant: ",$page);
		$pageCop = str_replace($localPath , "",  $page);
		$this->addDebugInfo("page apres: ",$pageCop);
            	// Change localpath and execute
		$chDir=chdir($localPath);
		$this->addDebugInfo("changing to local path: ",$chDir);
		if ($this->sshKeyPath==''){
                	$command = sprintf(
                        	'rsync -avz --relative -e "ssh -o StrictHostKeyChecking=no" --rsync-path="sudo -u www-data /usr/bin/rsync"  %s %s@%s:%s',
                        	$pageCop,
                        	$this->remoteUser,
                        	$this->remoteHost,
                        	$this->remotePath
                	);
		} else {
			$command = sprintf(
				'rsync -avz --relative -e "ssh -i %s -o StrictHostKeyChecking=no" --rsync-path="sudo -u www-data /usr/bin/rsync" %s %s@%s:%s',
				$this->sshKeyPath,
				$pageCop,
				$this->remoteUser,
				$this->remoteHost,
				$this->remotePath
			);
		}
		$this->addDebugInfo("command : ",$command);
        	exec($command . ' 2>&1', $output, $returnVar);
        	$result[] = [
			'command' => $command,
                	'page' => $page,
                	'output' => $output,
                	'success' => $returnVar === 0
        		];
		$this->addDebugInfo("result: ",$result);
		if ($this->usebeforeafter){
			$resultBeforeAfter =$this->beforeAfter($this->remotePath.'/'.$pageCop);
			$result=array_merge( $result,$resultBeforeAfter);
		}
        }
        return $result;
    }

}
